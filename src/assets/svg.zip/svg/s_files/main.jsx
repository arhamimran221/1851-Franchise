import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=abe7e40b"; const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=dc5bebb9"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=c637943d"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import App from "/src/App.jsx?t=1697782122463";
import "/src/index.css?t=1697785005530";
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/ _jsxDEV(React.StrictMode, {
    children: /*#__PURE__*/ _jsxDEV(App, {}, void 0, false, {
        fileName: "/Users/psi-square/Downloads/FranchiesDoc/my-franchies/src/main.jsx",
        lineNumber: 8,
        columnNumber: 5
    }, this)
}, void 0, false, {
    fileName: "/Users/psi-square/Downloads/FranchiesDoc/my-franchies/src/main.jsx",
    lineNumber: 7,
    columnNumber: 3
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1haW4uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBSZWFjdERPTSBmcm9tICdyZWFjdC1kb20vY2xpZW50J1xuaW1wb3J0IEFwcCBmcm9tICcuL0FwcC5qc3gnXG5pbXBvcnQgJy4vaW5kZXguY3NzJ1xuXG5SZWFjdERPTS5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCdyb290JykpLnJlbmRlcihcbiAgPFJlYWN0LlN0cmljdE1vZGU+XG4gICAgPEFwcCAvPlxuICA8L1JlYWN0LlN0cmljdE1vZGU+LFxuKVxuIl0sIm5hbWVzIjpbIlJlYWN0IiwiUmVhY3RET00iLCJBcHAiLCJjcmVhdGVSb290IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciIsIlN0cmljdE1vZGUiXSwibWFwcGluZ3MiOiI7QUFBQSxPQUFPQSxXQUFXLFFBQU87QUFDekIsT0FBT0MsY0FBYyxtQkFBa0I7QUFDdkMsT0FBT0MsU0FBUyxZQUFXO0FBQzNCLE9BQU8sY0FBYTtBQUVwQkQsU0FBU0UsVUFBVSxDQUFDQyxTQUFTQyxjQUFjLENBQUMsU0FBU0MsTUFBTSxlQUN6RCxRQUFDTixNQUFNTyxVQUFVO2NBQ2YsY0FBQSxRQUFDTCJ9