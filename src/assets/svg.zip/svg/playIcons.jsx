import React from 'react'

const playIcon = () => {
  return (
  
      <svg width="95" height="86" viewBox="0 0 95 86" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M95 43L0.500001 85.4352L0.5 0.564756L95 43Z" fill="white"/>
</svg>
  
  )
}

export default playIcon
